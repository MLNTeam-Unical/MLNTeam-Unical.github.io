#!/usr/bin/python
# -*- coding: latin-1 -*-

from os.path import basename
from os.path import exists
import os
import localCommunity1_lwsim
import localCommunity2_wlsim
import localCommunity3_clsim
from localCommunity1_lwsim import readGraph
from localCommunity1_lwsim import readCompactGraph
import numpy as np

r = 50

os.chdir('E:\\ROBERTO\\_LCD_\\RemoteSensing\\')
input_path = 'remote_sensing.txt'

outpath = "multirun_modularities.txt"
f = None

def multirun_lc1():
    outname = 'log1_multirun'
    print("Processing ",input_path)
    if input_path.endswith('.ncol'):
        layer_graphs, node_layers = readGraph(input_path)
    elif input_path.endswith('.txt'):
        layer_graphs, node_layers = readCompactGraph(input_path)

    layer_graphs_copy = {}  # serve per fase aggregation. consumo RAM ma risparmio tempo eventuale rilettura
    for l in layer_graphs.keys():
        layer_graphs_copy[l] = layer_graphs[l].copy()
    Qs = []
    for i in range(0,r):
        print("Run ",i)
        layer_graphs_copy = {}  # serve per fase aggregation. consumo RAM ma risparmio tempo eventuale rilettura
        for l in layer_graphs.keys():
            layer_graphs_copy[l] = layer_graphs[l].copy()
        Qs.append(localCommunity1_lwsim.main_LocToGlob(layer_graphs_copy, node_layers,i,outname))
    avg = np.mean(Qs)
    print("[LC1] Average Modularity for %d runs: %f" % (r,avg))
    f.write("[LC1] Average Modularity for %d runs: %f\n" % (r,avg))


def multirun_lc2():
    outname = 'log2_multirun'
    print("Processing ",input_path)
    if input_path.endswith('.ncol'):
        layer_graphs, node_layers = readGraph(input_path)
    elif input_path.endswith('.txt'):
        layer_graphs, node_layers = readCompactGraph(input_path)

    layer_graphs_copy = {}  # serve per fase aggregation. consumo RAM ma risparmio tempo eventuale rilettura
    for l in layer_graphs.keys():
        layer_graphs_copy[l] = layer_graphs[l].copy()
    Qs = []
    for i in range(0,r):
        print("Run ",i)
        layer_graphs_copy = {}  # serve per fase aggregation. consumo RAM ma risparmio tempo eventuale rilettura
        for l in layer_graphs.keys():
            layer_graphs_copy[l] = layer_graphs[l].copy()
        Qs.append(localCommunity2_wlsim.main_LocToGlob(layer_graphs_copy, node_layers,i,outname))
    avg = np.mean(Qs)
    print("[LC2] Average Modularity for %d runs: %f" % (r,avg))
    f.write("[LC2] Average Modularity for %d runs: %f\n" % (r,avg))


def multirun_lc3():
    outname = 'log3_multirun'
    print("Processing ",input_path)
    if input_path.endswith('.ncol'):
        layer_graphs, node_layers = readGraph(input_path)
    elif input_path.endswith('.txt'):
        layer_graphs, node_layers = readCompactGraph(input_path)

    layer_graphs_copy = {}  # serve per fase aggregation. consumo RAM ma risparmio tempo eventuale rilettura
    for l in layer_graphs.keys():
        layer_graphs_copy[l] = layer_graphs[l].copy()
    Qs = []
    for i in range(0,r):
        print("Run ",i)
        layer_graphs_copy = {}  # serve per fase aggregation. consumo RAM ma risparmio tempo eventuale rilettura
        for l in layer_graphs.keys():
            layer_graphs_copy[l] = layer_graphs[l].copy()
        Qs.append(localCommunity3_clsim.main_LocToGlob(layer_graphs_copy, node_layers,i,outname))
    avg = np.mean(Qs)
    print("[LC3] Average Modularity for %d runs: %f" % (r,avg))
    f.write("[LC3] Average Modularity for %d runs: %f\n" % (r,avg))
    


if __name__=='__main__':
    f = open(outpath,'a')
    multirun_lc1()
    multirun_lc2()
    multirun_lc3()
    f.close()