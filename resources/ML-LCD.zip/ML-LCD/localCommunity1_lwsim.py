#!/usr/bin/python
# -*- coding: latin-1 -*-

import networkx as nx
import random
import numpy as np
from preprocessing import readGraph
from preprocessing import readCompactGraph
import os
from modularity import multislice_modularity
import time
from os import mkdir
from os.path import exists
import sys

debug = 0

neighbors_all = {}  # dict incrementale dei vicini di ogni nodo su tutti i layer

# mlgraph_dict: dict nel formato {idlayer: oggetto_grafo}
def localCommunityIdentification(mlgraph_dict, node_layers, weights, v, f_lab):
    # code line 1
    D = [v]
    B = [v]
    S_set = set()
    removed_from_S = set()
    # S deve includere vicini da tutti i layer
    for layer in node_layers[v]:
        S_set.update(set(mlgraph_dict[layer].neighbors(v)))
    if D[0] in S_set:  # in caso di self-loop
        S_set.remove(D[0])
    S = list(S_set)
    # code line 2-3
    Lin = calculateLin(D, mlgraph_dict, node_layers, weights)
    Lex = calculateLex(B, S, mlgraph_dict, node_layers, weights)
    L = calculateL(Lin, Lex)
    if L==None and len(D)!=1 and len(B)!=1 and len(S)!=0:
        L=0
        print("[WARNING] 0/0 L on a non singleton community")
    if debug:
        print("Lin", Lin, "\nLex", Lex, "\nL", L)
    # code line 4
    while True:
        delta_max = 0
        arg_deltamax = -1
        if debug:
            print("=================while iteration=======================")
            print("S", S, "\nD", D, "\nB", B, "\nLin", Lin)
            print("=======================================================")
        curr_sumEc = Lin * len(D)  # Ind = weighted sum of Ec (wsum in metodo Lin)
        curr_sumEb = Lex * len(B)  # Outd = weighted sum of Eb (wsum in metodo Lex)
        # code line 5-6
        for i in S:
            # versione con eq.6 (formula ottimizzata per L') -modificata per contesto ML-weighted
            tupd = calcWeightedIndiOutdi(mlgraph_dict, node_layers, weights, D, S, i)
            ind_i = tupd[0]  # archi da i verso D
            outd_i = tupd[1]  # archi da i verso V-D
            Bupd = updateB(mlgraph_dict, node_layers, D, B, S, i)
            try:
                Li = ((curr_sumEc + 2 * ind_i) / (len(D) + 1)) / ((curr_sumEb - ind_i + outd_i) / (len(Bupd)))
            except ZeroDivisionError:
                    if (curr_sumEc > 0 or curr_sumEc==0 and len(D)==1) and len(Bupd) == 0:
                        #Li = 1# clique
                        D = D_add_node(D, i)
                        #print("[LCD] Clique discovered: ", D)
                        tup_lab = labeling(D, mlgraph_dict,node_layers, weights)
                        print_labs(tup_lab, f_lab, v)
                        return list(np.unique(D))
                    else:
                        print("WARNING: ZeroDivisionError when calculating Li, returning 0")
                        print("S", S, "\nD", D, "\nB", B, "\ni",i,"\nsumEc ",curr_sumEc,"\nLin",Lin)
                        Li = 0  # error
            delta = Li - L
            if debug:
                print("i", i, "\nLi", Li, "\delta", delta)
            if delta > delta_max:
                delta_max = delta
                arg_deltamax = i
        # code line 7
        if arg_deltamax == -1 or delta_max <= 0:
            #print("=== BREAK: No more good candidates ===")
            break  # Nessun candidato incrementa L, Ld non pu� essere massimizzato oltre
        # code line 8-9
        D_i = D_add_node(D, arg_deltamax)
        updBS = calcBS(D_i, mlgraph_dict, node_layers, removed_from_S)
        Bupd = updBS[0]
        Supd = updBS[1]
        # non posso usare formula ottimizzata perche' mi serve esplicitamente Lin
        Lin_i = calculateLin(D_i, mlgraph_dict, node_layers, weights)
        Lex_i = calculateLex(Bupd, Supd, mlgraph_dict, node_layers, weights)
        L_i = calculateL(Lin_i, Lex_i)
        if L_i == None:
            print("[None L [0/0]   S", S, "\nD", D, "\nB", B, "\ni",i,"\nsumEc ",curr_sumEc,"\nLin",Lin)
        if debug:
            print("Lin_i", Lin_i, "Lin", Lin)
        if L_i > L and Lin_i > Lin:  #a quanto pare il calcolo di Lin_i � la fase pi� "delicata"
            # se va bene, "confermo" gli update
            D = D_i
            B = Bupd
            S = Supd
            L = L_i
            Lin = Lin_i
            Lex = Lex_i
        # code line 10-11
        else:
            # D rimane uguale, aggiorno S e B
            S.remove(arg_deltamax)
            removed_from_S.add(arg_deltamax)
            B = updateB(mlgraph_dict, node_layers, D, B, S, arg_deltamax)
    # code line 14

    # pruning phase
    #pruning(D, Lin, Lex, mlgraph_dict, weights)

    #labeling phase (alternative to old pruning phase)
    tup_lab = labeling(D, mlgraph_dict,node_layers, weights)
    print_labs(tup_lab, f_lab, v)

    if (v in D):
        return list(np.unique(D))
    else:
        print("[localCommunityIdentification] Target node non in local community: returning None")
        return None


def calculateLin(D, mlgraph_dict, node_layers, weights):
    if (len(D) == 0):
        print("[calculateLin] Warning: empty D set, returning 0")
        return 0
    wSum = 0.0
    for i in D:
        for ly in node_layers[i]:
            #EcL = 0
            l = mlgraph_dict[ly].neighbors(i)
            EcL = len(set(l).intersection(set(D)))
            """
            if len(l) <= len(D):
                for j in l:
                    if j in D:
                        EcL += 1
            else:
                for j in D:
                    if j in l:
                        EcL += 1
            """
            wSum += EcL * weights[ly]
    return wSum / float(len(D))


def calculateLex(B, S, mlgraph_dict, node_layers, weights):
    if (len(B) == 0):
        #print("[calculateLex] Warning: empty B set, returning 0")
        return 0
    wSum = 0.0
    for i in B:
        for ly in node_layers[i]:
            #EbL = 0
            l = mlgraph_dict[ly].neighbors(i)
            EbL = len(set(l).intersection(set(S)))
            """
            if len(l) <= len(S):
                for j in l:
                    if j in S:
                        EbL += 1
            else:
                for j in S:
                    if j in l:
                        EbL += 1
            """
            wSum += EbL * weights[ly]
    return wSum / float(len(B))


# versione pesata sui vari layer
def calcWeightedIndiOutdi(mlgraph_dict, node_layers, weights, D, S, i):
    indi = 0
    outdi = 0
    for ly in node_layers[i]:
        l = mlgraph_dict[ly].neighbors(i)
        l_set = set(l)
        indi  += len(l_set.intersection(set(D)))*weights[ly]
        outdi += len(l_set.intersection(set(S)))*weights[ly]
        """
        for j in l:
            if j in D:
                indi += 1 * weights[ly]
            elif j in S:
                outdi += 1 * weights[ly]
        """
    return indi, outdi


def updateB(mlgraph_dict, node_layers, D, B, S, i):
    Bupd = []
    Bupd.extend(B)
    to_remove = set()
    added = False
    if debug:
        print("Updating B wrt node %d" % i)
    for ly in node_layers[i]:
        l = mlgraph_dict[ly].neighbors(i)
        for j in l:
            if j in B:  # all i's neighbors in B for layer ly
                if j not in neighbors_all:
                    neigh_j = set()
                    for lx in node_layers[j]:  # devo prendere i vicini di j su tutti i layer!
                        neigh_j.update(set(mlgraph_dict[lx].neighbors(j)))
                    neighbors_all[j] = np.array(list(neigh_j))
                S_neighs_np = set(S).intersection(set(neighbors_all[j]))
                #S_np = np.array(S)
                #S_neighs_np = np.intersect1d(S_np, neighbors_all[j], assume_unique=True)
                if len(S_neighs_np) == 0 or (len(S_neighs_np) == 1 and i in S_neighs_np):  #se j non ha vicini in S o l'unico era i, esce da B
                    to_remove.add(j)
            elif not added:
                if j in S:  # se ha vicini fuori da D deve stare in B
                    if i not in Bupd:
                        Bupd.append(i)
                        added = True
    for x in to_remove:
        try:
            Bupd.remove(x)
        except ValueError:
            print("[updateB] ValueError when removing ",x," from ",Bupd)
    return list(np.unique(Bupd))


def calculateL(lin, lex):
    if lex == 0:
        if lin > 0:
            #print("[calculateL] Warning: clique, returning 1")
            return 1
        else:
            #print("[calculateL] Warning: 0/0, returning None")
            return None
    return float(lin) / float(lex)


# removing v1
def D_remove_node(D, v1):
    D1 = []
    D1.extend(D)
    D1.remove(v1)
    return D1


# add v1
def D_add_node(D, v1):
    D1 = []
    D1.extend(D)
    D1.append(v1)
    return D1


def calcBS(D, mlgraph_dict, node_layers, removed_from_S):
    B = set()
    S = set()
    for i in D:
        for ly in node_layers[i]:
            li = mlgraph_dict[ly].neighbors(i)
            for ni in li:
                if ni not in D and ni not in removed_from_S:
                    B.add(i)
                    S.add(ni)
    return list(B), list(S)


def pruning(D, Lin, Lex, mlgraph_dict, weights):
    for i in D:
        if debug:
            print("========== Pruning ==============")
            print("D before pruning: ", D)
        D_mi = D_remove_node(D, i)  # D minus i
        tupBS = calcBS(D_mi, mlgraph_dict, set())  # check se serve set di removed_from_S (non dovrebbe)
        B_mi = tupBS[0]  # B associated to D_mi
        S_mi = tupBS[1]
        Lin_mi = calculateLin(D_mi, mlgraph_dict, weights)
        Lex_mi = calculateLex(B_mi, S_mi, mlgraph_dict, weights)
        if (Lex_mi == -1):
            return None
        # code line 15-16
        if debug:
            print("i", i, "Lin", Lin, "Lin'", Lin_mi, "Lex", Lex, "Lex'", Lex_mi)
        if not (Lin > Lin_mi and Lex < Lex_mi):
            if debug:
                print("Removing %d" % i)
            D.remove(i)


# internal and external (weighted) connections invece di triads
def labeling(D, mlgraph_dict, node_layers, weights):
    Ec = []
    Ec_dict = {}
    Eb_dict = {}
    for i in D:
        Ec_i = 0.0
        Eb_i = 0.0
        for ly in node_layers[i]:
            EcL = 0
            EbL = 0
            l = mlgraph_dict[ly].neighbors(i)
            for j in l:
                if j in D:
                    EcL += 1
                else:
                    EbL += 1
            Ec_i += EcL * weights[ly]
            Eb_i += EbL * weights[ly]
        Ec.append(Ec_i)
        Ec_dict[i] = Ec_i
        Eb_dict[i] = Eb_i
    Ec_np = np.array(Ec)
    avg = np.mean(Ec_np)
    st_dev = np.std(Ec_np)
    hubs = set()
    outliers = set()
    for i in D:
        if Ec_dict[i] < (avg - st_dev) and Eb_dict[i] == 0:
            outliers.add(i)
        if Eb_dict[i] > Ec_dict[i]:
            hubs.add(i)
    return hubs, outliers


def print_labs(tup_lab, f_lab, v):
    f_lab.write(str(v) + ": ")
    f_lab.write("hubs: " + str(tup_lab[0]) + " outliers: " + str(tup_lab[1]) + "\n")


def choose_seed(nodeset, layer_graphs):
    start = random.sample(nodeset, 1)[0]
    maxdeg = 0
    maxdeg_id = start
    candidates = set()
    candidates.add(start)
    for l in layer_graphs:
        if start in layer_graphs[l].nodes():
            maxdeg += len(layer_graphs[l].neighbors(start))
            candidates.update(set(layer_graphs[l].neighbors(start)))
    for c in candidates:
        c_deg = 0
        for l in layer_graphs:
            if start in layer_graphs[l].nodes():
                c_deg += len(layer_graphs[l].neighbors(start))
        if c_deg > maxdeg:
            maxdeg = c_deg
            maxdeg_id = c
    return maxdeg_id

# versione incrementale OTTIMIZZATA
def aggregation_incr(Ds, layer_graphs, node_layers, weights):
    Ls = {}
    Lins = {}
    Lexs = {}
    cliques = set()
    sing = []
    mult = {}
    for c in Ds.keys():
        if len(Ds[c]) == 1:
            sing.append(Ds[c])
        else:
            mult[c] = Ds[c]
    print("Single Communities: ", len(sing))
    print("Non-single communities: ", len(mult))
    maxdelta = 0
    arg_maxdelta = -1
    Li_maxdelta = -1
    Lini_maxdelta = -1
    count = 0
    for c in sing:
        if count % 500 == 0:
            print("=================================================   Analyzing singleton numb. : ", count)
        count += 1
        nc = set()
        for l in node_layers[c[0]]:
            nc.update(set(layer_graphs[l].neighbors(c[0])))
        for D_k in mult:
            if D_k not in cliques:
                D = mult[D_k]
                isec = set(nc).intersection(set(mult[D_k]))# calcolo L solo se c'� intersezione di vicini
                if len(isec) > 0:
                    if D_k in Ls:
                        L = Ls[D_k]
                        Lin = Lins[D_k]
                        Lex = Lexs[D_k]
                    else:
                        Lin = calculateLin(D, layer_graphs, node_layers,weights)
                        t = calcBS(D, layer_graphs, node_layers, set())
                        Lex = calculateLex(t[0], t[1], layer_graphs, node_layers,weights)
                        L = calculateL(Lin, Lex)
                        Ls[D_k]=L
                        Lins[D_k] = Lin
                        Lexs[D_k] = Lex
                    curr_sumEc = Lin * len(D)  # Ind = weighted sum of Ec (wsum in metodo Lin)
                    curr_sumEb = Lex * len(t[0])  # Outd = weighted sum of Eb (wsum in metodo Lex)
                    tupd = calcWeightedIndiOutdi(layer_graphs, node_layers,weights, D, t[1], c[0])
                    ind_i = tupd[0]  # archi da i verso D
                    outd_i = tupd[1]  # archi da i verso V-D
                    Bupd = updateB(layer_graphs, node_layers, D, t[0], t[1], c[0])
                    try:
                        Li = ((curr_sumEc + 2 * ind_i) / (len(D) + 1)) / ((curr_sumEb - ind_i + outd_i) / (len(Bupd)))
                        Lin_i = ((curr_sumEc + 2 * ind_i) / (len(D) + 1))
                    except ZeroDivisionError:
                        if curr_sumEc > 0 and len(Bupd) == 0:
                            # clique
                            mult[D_k].append(c[0])
                            #print("[Aggregation] Clique discovered: ", mult[D_k])
                            cliques.add(D_k) #rimuovo la clique: non occorre confrontarla con altri
                            break
                        else:
                            Li = 0  # error
                    delta = Li - L
                    if delta > maxdelta:
                        maxdelta = delta
                        arg_maxdelta = D_k
                        Li_maxdelta = Li
                        Lini_maxdelta = Lin_i
        if arg_maxdelta != -1:
            mult[arg_maxdelta].append(c[0])
            Ls[arg_maxdelta] = Li_maxdelta
            Lins[arg_maxdelta] = Lini_maxdelta
            Lexs[arg_maxdelta] = Lini_maxdelta/Li_maxdelta
        else:
            mult[c[0]] = c
    return mult

#per utilizzo con multirun
def main(layer_graphs, node_layers,r):
    layer_graphs_copy = {}  # serve per fase aggregation. consumo RAM ma risparmio tempo eventuale rilettura
    for l in layer_graphs.keys():
        layer_graphs_copy[l] = layer_graphs[l].copy()
    # popolo nodeset globale per esecuzione algo
    nodeset = set()
    for l in layer_graphs.keys():
        nodeset.update(set(layer_graphs[l].nodes()))

    weights_dict = {}
    uniform_weight = 1.0 / float(len(layer_graphs.keys()))
    #print("Using uniform weight: %f" % uniform_weight)
    for l in layer_graphs.keys():
        weights_dict[l] = uniform_weight

    Ds = {}
    # inserire argomenti a linea di comando o altro per pesi diversi...o distrib random...
    #print("Nodes in nodeset: %d" % len(nodeset))
    tot_nodes = len(nodeset)
    while len(nodeset) > 0:
        if len(nodeset) % 1000 == 0:
            print(len(nodeset), " node processed over ", tot_nodes)
        start = choose_seed(nodeset, layer_graphs)
        # print("Calculating local community for node %d" % start)
        f = open("./log1_nonverlapping.txt", "a")
        f_lab = open("./log1_nonoverlapping_labeling.txt", "a")
        D = localCommunityIdentification(layer_graphs, node_layers, weights_dict, start, f_lab)
        if D is not None:
            f.write(str(start) + ": " + str(D) + "\n")
        else:
            f.write(str(start) + ": []" + "\n")
        f.close()
        f_lab.close()
        Ds[start] = D
        # print("Removing nodes in the discovered community from the graph...")
        for i in D:
            nodeset.remove(i)
            for l in node_layers[i]:
                layer_graphs[l].remove_node(i)
     #   print("\n\nIncrementalAggr")

    aggd_incr = aggregation_incr(Ds, layer_graphs_copy, node_layers, weights_dict)

    if not exists('./Output_multirun/%d/' % r):
        mkdir('./Output_multirun/%d/' % r)
    f = open("./Output_multirun/%d/log1_nonverlapping_aggr_incr.txt" % r, "a")
    for d in aggd_incr:
        f.write(str(d) + ": " + str(aggd_incr[d]) + "\n")
    Q = multislice_modularity(layer_graphs_copy, aggd_incr)
    print("Run %d Modularity: %f" % (r,Q))
    return Q

def choose_seed(nodeset, layer_graphs):
    start = random.sample(nodeset, 1)[0]
    maxdeg = 0
    maxdeg_id = start
    candidates = set()
    candidates.add(start)
    for l in layer_graphs:
        if start in layer_graphs[l].nodes():
            maxdeg += len(layer_graphs[l].neighbors(start))
            candidates.update(set(layer_graphs[l].neighbors(start)))
    for c in candidates:
        c_deg = 0
        for l in layer_graphs:
            if start in layer_graphs[l].nodes():
                c_deg += len(layer_graphs[l].neighbors(start))
        if c_deg > maxdeg:
            maxdeg = c_deg
            maxdeg_id = c
    return maxdeg_id

#per utilizzo con multirun
def main_LocToGlob(layer_graphs, node_layers,r, outname):
    layer_graphs_copy = {}  # serve per fase aggregation. consumo RAM ma risparmio tempo eventuale rilettura
    for l in layer_graphs.keys():
        layer_graphs_copy[l] = layer_graphs[l].copy()
    # popolo nodeset globale per esecuzione algo
    nodeset = set()
    for l in layer_graphs.keys():
        nodeset.update(set(layer_graphs[l].nodes()))

    weights_dict = {}
    uniform_weight = 1.0 / float(len(layer_graphs.keys()))
    #print("Using uniform weight: %f" % uniform_weight)
    for l in layer_graphs.keys():
        weights_dict[l] = uniform_weight

    Ds = {}
    # inserire argomenti a linea di comando o altro per pesi diversi...o distrib random...
    #print("Nodes in nodeset: %d" % len(nodeset))
    tot_nodes = len(nodeset)
    while len(nodeset) > 0:
        if len(nodeset) % 1000 == 0:
            print(len(nodeset), " node processed over ", tot_nodes)
        start = choose_seed(nodeset, layer_graphs)
        # print("Calculating local community for node %d" % start)
        #f = open("./log1_nonverlapping.txt", "w")
        f_lab = open("./log1_nonoverlapping_labeling_tmp.txt", "w")
        D = localCommunityIdentification(layer_graphs, node_layers, weights_dict, start, f_lab)
        #if D is not None:
        #    f.write(str(start) + ": " + str(D) + "\n")
        #else:
        #    f.write(str(start) + ": []" + "\n")
        #f.close()
        #f_lab.close()
        Ds[start] = D
        # print("Removing nodes in the discovered community from the graph...")
        for i in D:
            nodeset.remove(i)
            for l in node_layers[i]:
                layer_graphs[l].remove_node(i)
     #   print("\n\nIncrementalAggr")

    aggd_incr = aggregation_incr(Ds, layer_graphs_copy, node_layers, weights_dict)

    if not exists('./Output_multirun/%d/' % r):
        mkdir('./Output_multirun/%d/' % r)
    f = open("./Output_multirun/%d/%s.txt" % (r,outname), "w")
    for d in aggd_incr:
        f.write(str(d) + ": " + str(aggd_incr[d]) + "\n")
    Q = multislice_modularity(layer_graphs_copy, aggd_incr)
    print("Run %d Modularity: %f" % (r,Q))
    return Q

def main_allGraph():
    """
        #os.chdir("/home/intagro/data/HiggsTwitter/remapped [ROB-08 04 2016]/")
        #input_path = "higgs_multiplex_3layers.edges.remapped"
        #layer_graphs, node_layers = readGraph(input_path)

        # os.chdir("/home/intagro/data/ML/flickr/")
        #input_path = "edges.txt"
        #layer_graphs,node_layers = readCompactGraph(input_path)

        #os.chdir("/home/intagro/data/ML/dblp/")
        #input_path = "edges.txt"
        #layer_graphs,node_layers = readCompactGraph(input_path)

        os.chdir('/home/rob/DATA/AUCS/')
        input_path = 'aucs_remapped.ncol'
        layer_graphs, node_layers = readGraph(input_path)


        os.chdir('/home/rob/DATA/air-multi-public-dataset/')
        input_path = "airlines_remapped.ncol"
        layer_graphs, node_layers = readGraph(input_path)

        os.chdir('/home/rob/DATA/AUCS/')
        input_path = 'aucs_remapped.ncol'

        os.chdir('/home/rob/DATA/twytff/')
        input_path = 'twytff_remapped.ncol'
        layer_graphs, node_layers = readGraph(input_path)

        os.chdir("/home/rob/DATA/reality_mining/")
        input_path = "reality_mining_noSelfLoops.ncol"
        layer_graphs, node_layers = readGraph(input_path)


        """

    print("Computing local (overlapping) communities with ML-LCD-lwsim method")
    if len(sys.argv) > 1:
        input_path = sys.argv[1]
        output_dir = sys.argv[2]
        output_name = sys.argv[3]
    else:
        os.chdir('/home/rob/DATA/dblp/')
        input_path = 'edges.txt'
        output_dir = './'
        output_name = 'log1_overlapping_TEMPn'

    if input_path.endswith('.ncol'):
        layer_graphs, node_layers = readGraph(input_path)
    elif input_path.endswith('.txt'):
        layer_graphs, node_layers = readCompactGraph(input_path)

    # popolo nodeset globale per esecuzione algo
    nodeset = set()
    for l in layer_graphs.keys():
        nodeset.update(set(layer_graphs[l].nodes()))

    weights_dict = {}

    uniform_weight = 1.0 / float(len(layer_graphs.keys()))
    print("Using uniform weight: %f" % uniform_weight)
    for l in layer_graphs.keys():
        weights_dict[l] = uniform_weight

    # inserire argomenti a linea di comando o altro per pesi diversi...o distrib random...
    print("Nodes in nodeset: %d" % len(nodeset))
    tot_nodes = len(nodeset)

    if exists("%s%s.txt" % (output_dir, output_name)):
        print("Warning: output file already exists, appending communities")

    for start in nodeset:
        if len(nodeset) % 1000 == 0:
            print(len(nodeset), " node processed over ", tot_nodes)
        # print("Calculating local community for node %d" % start)
        f = open("%s%s.txt" % (output_dir, output_name), "a")
        f_lab = open("%s%s_labeling.txt" % (output_dir, output_name), "a")
        D = localCommunityIdentification(layer_graphs, node_layers, weights_dict, start, f_lab)
        if D is not None:
            f.write(str(start) + ": " + str(D) + "\n")
        else:
            f.write(str(start) + ": []" + "\n")
        f.close()
        f_lab.close()

def main_singleNode():
    #print("Computing local (overlapping) communities with ML-LCD-lwsim method")
    if len(sys.argv) > 1:
        input_path = sys.argv[1]
        input_node = sys.argv[2]
        output_dir = sys.argv[3]
    else:
        print("Args missing")
        exit()

    output_name = '%s%s_lwsim.txt' % (output_dir,input_node)

    if input_path.endswith('.ncol'):
        layer_graphs, node_layers = readGraph(input_path)
    elif input_path.endswith('.txt'):
        layer_graphs, node_layers = readCompactGraph(input_path)

    if int(input_node) not in node_layers:
       exit()

    weights_dict = {}

    uniform_weight = 1.0 / float(len(layer_graphs.keys()))
    #print("Using uniform weight: %f" % uniform_weight)
    for l in layer_graphs.keys():
        weights_dict[l] = uniform_weight


    f = open(output_name, "w")
    f_lab = open("%s%s_lwsim_labeling.txt" % (output_dir, input_node), "w")
    D = localCommunityIdentification(layer_graphs, node_layers, weights_dict, int(input_node), f_lab)
    if D is not None:
        f.write(str(input_node) + ": " + str(D) + "\n")
    else:
        f.write(str(input_node) + ": []" + "\n")
    f.close()
    f_lab.close()

if __name__ == '__main__':
    main_singleNode()
