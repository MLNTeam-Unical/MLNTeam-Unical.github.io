
###################################################################
### ML-LCD code (DAMI 20217)
###
### DIMES, University of Calabria
### v. P. Bucci 44, 87036 Rende (CS), Italy
### 
### Copyright R. Interdonato, A. Tagarelli, 2017 
###
### TERMS OF USAGE:
### 1. The following paper is to be cited in any research product 
### whose findings are based on the data here distributed:
### 
### Roberto Interdonato, Andrea Tagarelli, Dino Ienco, 
### Arnaud Sallaberry, Pascal Poncelet. 
### Local Community Detection in Multilayer Networks. 
### Data Mining and Knowledge Discovery, Springer, 
### Vol. 31, Issue 5, pp. 1444-1479, 2017. 
### DOI: https://doi.org/10.1007/s10618-017-0525-y
###
### 2. The code cannot be redistributed.
###################################################################


QSG 
====

Each Python script refers to a different ML-LCD formulation (reported in the scriptname):

localCommunity1_lwsim
localCommunity2_wlsim
localCommunity3_clsim


Usage: 

python localCommunity1_lwsim.py  <input_path> <input_node> <output_dir>

(see 'main_allGraph()' method in each script for batch execution on all nodes of an input graph)


For LocToGlob experiments, use:

multirun
