#!/usr/bin/python
# -*- coding: latin-1 -*-

import os
import networkx as nx

def readGraph(input_path):
    node_layers = {} # per ogni nodo, layer a cui appartiene
    layer_graphs = {}
    f = open(input_path, 'r')
    for line in f:
        vals = line.split(" ")
        layer = int(vals[2].strip())
        a = int(vals[0].strip())
        b = int(vals[1].strip())
        if layer not in layer_graphs:
            layer_graphs[layer] = nx.Graph()
        layer_graphs[layer].add_edge(a, b)
        if a not in node_layers:
            node_layers[a] = set()
        if b not in node_layers:
            node_layers[b] = set()
        node_layers[a].add(layer)
        node_layers[b].add(layer)
    return layer_graphs,node_layers


def readCompactGraph(input_path):
    node_layers = {} # per ogni nodo, layer a cui appartiene
    layer_graphs = {}
    f = open(input_path, 'r')
    for line in f:
        vals = line.split(" ")
        layers = vals[2].strip().split(',')
        a = int(vals[0].strip())
        b = int(vals[1].strip())
        for layer_s in layers:
            layer = int(layer_s)
            if layer not in layer_graphs:
                layer_graphs[layer] = nx.Graph()
            layer_graphs[layer].add_edge(a, b)
            if a not in node_layers:
                node_layers[a] = set()
            if b not in node_layers:
                node_layers[b] = set()
            node_layers[a].add(layer)
            node_layers[b].add(layer)
    return layer_graphs,node_layers


def realityminingPreprocess():
    os.chdir(r'C:\Users\rzint\OneDrive\Documenti\LCD\Data\reality-mining')
    p1 = "call.csv"
    p2 = "FR.csv"
    p3 = "text.csv"
    ps = [p1,p2,p3]
    out = "reality_mining.ncol"
    fout = open(out,'w')
    id = 0
    for p in ps:
        f = open(p,'r')
        for line in f:
            vs = line.split(" ")
            fout.write("%s %s %d\n" % (vs[0].strip(),vs[1].strip(),id))
        id+=1
        f.close()
    fout.close()


def HiggsTwitter():
    os.chdir('/home/rob/DATA/HiggsTwitter/')
    p = "higgs_multiplex_4layers.edges"
    out1 = "higgs_multiplex_4layers.edges.remapped"
    out2 = "higgs_multiplex_3layers.edges.remapped"
    fout1 = open(out1,'w')
    fout2 = open(out2,'w')
    f = open(p,'r')
    map1 = "higgs_multiplex_4layers.edges.mapping"
    map2 = "higgs_multiplex_3layers.edges.mapping"
    fmap1 = open(map1,'w')
    fmap2 = open(map2,'w')
    idcounter1 = 0
    idcounter2 = 0
    idset1 = {}
    idset2 = {}

    for line in f:
        vs = line.split(" ")
        lay1 = int(vs[0])-1
        lay2 = int(vs[0])-2
        id1 = int(vs[1])
        id2 = int(vs[2])
        if id1 not in idset1.keys():
            id_a1 = idcounter1
            fmap1.write("%s %d\n" % (id1, idcounter1))
            idset1[id1] = id_a1
            idcounter1 += 1
        else:
            id_a1 = idset1[id1]
        if id2 not in idset1.keys():
            id_b1 = idcounter1
            fmap1.write("%s %d\n" % (id2, idcounter1))
            idset1[id2] = id_b1
            idcounter1 += 1
        else:
            id_b1 = idset1[id2]
        fout1.write("%d %d %d\n" % (id_a1, id_b1, lay1))
        if lay1 != 0:
            if id1 not in idset2.keys():
                id_a2 = idcounter2
                fmap2.write("%s %d\n" % (id1, idcounter2))
                idset2[id1] = id_a2
                idcounter2 += 1
            else:
                id_a2 = idset2[id1]
            if id2 not in idset2.keys():
                id_b2 = idcounter2
                fmap2.write("%s %d\n" % (id2, idcounter2))
                idset2[id2] = id_b2
                idcounter2 += 1
            else:
                id_b2 = idset2[id2]
            fout2.write("%d %d %d\n" % (id_a2, id_b2, lay2))
    f.close()
    fout1.close()
    fout2.close()


def PMMformat():

    os.chdir('/home/rob/DATA/AUCS/')
    input = "aucs_remapped.ncol"
    f = open(input, 'r')
    ls = 5
    files = {}
    for i in range(0,ls):
        files[i]=open("layer_%d.ncol" % i,'w')
    for line in f:
        vals = line.split(' ')
        lay = vals[2].strip()
        files[int(lay)].write("%s %s\n" % (vals[0],vals[1]))
    for k in files:
        files[k].close()

def PMMformatDoubleEdges():

    os.chdir('/home/rob/DATA/twytff/')
    input = "twytff_remapped.ncol"
    f = open(input, 'r')
    ls = 3
    files = {}
    for i in range(0,ls):
        files[i]=open("layer_%d.ncol" % i,'w')
    for line in f:
        vals = line.split(' ')
        lay = vals[2].strip()
        files[int(lay)].write("%s %s\n" % (vals[0],vals[1]))
        files[int(lay)].write("%s %s\n" % (vals[1], vals[0]))
    for k in files:
        files[k].close()

def PMMformatDoubleEdges_compact():

    os.chdir('/home/rob/DATA/dblp/')
    input = "edges.txt"
    f = open(input, 'r')
    ls = 50
    files = {}
    for i in range(0,ls):
        files[i]=open("layer_%d.ncol" % i,'w')
    for line in f:
        vals = line.split(' ')
        lays = vals[2].split(',')
        for lay in lays:
            files[int(lay)].write("%s %s\n" % (vals[0],vals[1]))
            files[int(lay)].write("%s %s\n" % (vals[1], vals[0]))
    for k in files:
        files[k].close()

"""
        f0=open("rm0.ncol", 'w')
    f1 = open("rm1.ncol", 'w')
    f2 = open("rm2.ncol", 'w')
    for line in f:
        vals = line.split(' ')
    lay = vals[2].strip()
    if lay == '0':
        f0.write("%s %s\n" % (vals[0], vals[1]))
    elif lay == '1':
        f1.write("%s %s\n" % (vals[0], vals[1]))
    elif lay == '2':
        f2.write("%s %s\n" % (vals[0], vals[1]))
    f0.close()
    f1.close()
    f2.close()
"""

def realitymining_Clean():
    os.chdir('/home/rob/DATA/reality_mining/')
    input = "reality_mining.ncol"
    f = open(input,'r')
    fo = open("reality_mining_noSelfLoops.ncol",'w')
    for line in f:
        vals = line.split(' ')
        lay = vals[2].strip()
        if vals[0]!=vals[1]:
            fo.write("%s %s %s\n" % (vals[0],vals[1],lay))
    fo.close()


def airlines():
    os.chdir('/home/rob/DATA/air-multi-public-dataset/')
    input = 'network.txt'
    output = 'airlines_remapped.ncol'
    f = open(input,'r')
    fo = open(output,'w')
    l = -1
    print("Parsing layer ", l)
    for line in f:
        vals = line.split('\t')
        if len(vals)==1 and vals[0]!='\n':
            l+=1
            print("Parsing layer ",l)
        elif len(vals)>=2:
            id = int(vals[0])
            for n in vals[2:]:
                n_id = int(n.strip())
                fo.write("%d %d %d\n" % (id,n_id,l))
    f.close()
    fo.close()

def AUCS():
    os.chdir('/home/rob/DATA/AUCS/')
    input = 'aucs.mpx.mpx'
    output = 'aucs_remapped.ncol'
    layers = {}
    users = {}
    l_count = 0
    id_c = 0
    f = open(input, 'r')
    fo = open(output, 'w')
    for line in f:
        vals = line.split(',')
        l = vals[2].strip()
        if vals[0] not in users:
            users[vals[0]] = id_c
            print(vals[0], id_c)
            id_c+=1
        if vals[1] not in users:
            users[vals[1]] = id_c
            print(vals[1], id_c)
            id_c+=1
        if l not in layers:
            layers[l] = l_count
            l_count+=1
        fo.write("%d %d %d\n" % (users[vals[0]], users[vals[1]], layers[l]))
    print("=========== Layers Mapping ============")
    for l in layers:
        print(l,layers[l])
    f.close()
    fo.close()

def twytff():
    os.chdir('/home/rob/DATA/twytff/')
    input = 'twytff.csv'
    output = 'twytff_remapped_noselfloops.ncol'
    layers = {}
    users = {}
    l_count = 0
    id_c = 0
    f = open(input, 'r')
    fo = open(output, 'w')
    for line in f:
        vals = line.split(' ')
        l = vals[2].strip()
        if vals[0] not in users:
            users[vals[0]] = id_c
            print(vals[0], id_c)
            id_c+=1
        if vals[1] not in users:
            users[vals[1]] = id_c
            print(vals[1], id_c)
            id_c+=1
        if l not in layers:
            layers[l] = l_count
            l_count+=1
        if users[vals[0]]!=users[vals[1]]:
            fo.write("%d %d %d\n" % (users[vals[0]], users[vals[1]], layers[l]))
    print("=========== Layers Mapping ============")
    for l in layers:
        print(l,layers[l])
    f.close()
    fo.close()



if __name__ == '__main__':
    os.chdir('/home/rob/DATA/air-multi-public-dataset/')
    input_path = "airlines_remapped.ncol"
    layer_graphs, node_layers = readGraph(input_path)

    #for l in layer_graphs:
    #    print(l,len(layer_graphs[l].nodes()))
    #print("===================")
    hub = 0
    nhub = 0
    s = 0

    for n in node_layers:
        if len(node_layers[n])>len(layer_graphs)/2:
            hub+=1
            nhub+=len(node_layers[n])
        elif len(node_layers[n])==1:
            s+=1
    print(hub,s)
    print(nhub/hub)





    #PMMformatDoubleEdges_compact()
    #PMMformatDoubleEdges()
    #twytff()
    #AUCS()
    #airlines()
    #realitymining_Clean()
    #realityminingPMM()